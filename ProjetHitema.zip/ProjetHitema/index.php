<html>
	<header>
		<!-- Titre -->
		<title>
			Projet-Hitema
		</title>
		<!-- style bootstrap -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<!-- Feuille de style -->
		<link rel="stylesheet" href="css/style.css" type="text/css" />
	</header>
	<body>

		<?php
		session_start();
		require_once('backend/connectMenu.php');
		?>
		
            <!--Intro Section-->
            <section class="view intro-2 hm-gradient">
                <div class="full-bg-img test">
                    <div class="container">
                        <div class="row">
                        	<div class="col-md-4 offset-md-4 text-center mt-5">
                        	</div>
                        </div>
                        <div class="row">
                        	<div class="col-md-4 offset-md-4 text-center mt-5">
                        	</div>
                        </div>
                        <div class="row">
                        	<div class="col-md-4 offset-md-4 text-center mt-5">
                        	</div>
                        </div>
                        <div class="row">
                        	<div class="col-md-6 offset-md-3 text-center">
                        		<div class="jumbotron jumbotron1">
								  <h1 class="display-4">Bienvenue à vous,</h1>
								  <p class="lead">ce projet à pour but la création d'une application de location de logements entre particuliers.</p>
								  <hr class="my-4">
								  <p>Pour effectuer votre recherche, cliquez sur le bouton ci-dessous.</p>
								  <p class="lead">
								    <a class="btn btn-primary btn-lg" href="backend/map.php" role="button">Recherche</a>
								  </p>
								</div>
                        	</div>
                        </div>
                    </div>
                </div>
                
            </section>

			<!--Popup modal-->
			<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			  <div class="modal-dialog" role="document">
			    <div class="modal-content">
			      <div class="modal-header">
			        <h5 class="modal-title" id="exampleModalLabel">Identification</h5>
			        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			          <span aria-hidden="true">&times;</span>
			        </button>
			      </div>
			      <div class="modal-body">
			      	<form action="backend/GestionConnexion.php" method="POST">
			  		<div class="form-group">
				        <label>Identifiant</label>
				        <input class="form-control" type="text" name="username"><br>
				    	</div>
			        <div class="form-group">
				        <label>Mot de passe</label>
				        <input class="form-control" type="password" name="password">
			      	</div>
			      <div class="modal-footer">
			      	<button type="submit" class="btn btn-primary" name="submitValidation" required>Se connecter</button>
			      	</form>
			        <button type="button" class="btn btn-secondary" data-dismiss="modal" required>Fermer</button>
			      </div>
			    </div>
			  </div>


			</div>
	</body>
	<footer>
		<script src="style/javascriptaccueil.js"></script>
	</footer>
</html>