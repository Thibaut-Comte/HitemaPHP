
<!doctype html>
<html lang="fr">
<head>
	<meta charset="utf-8">
	<title>TestsMap</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<!-- Feuille de style -->
		<link rel="stylesheet" href="../css/map.css" type="text/css" />

		<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>

		<link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.4/dist/leaflet.css"
		integrity="sha512-puBpdR0798OZvTTbP4A8Ix/l+A4dHDD0DGqYW6RQ+9jxkRFclaxxQb/SJAWZfWAkuyeQUytO7+7N4QKrDh+drA=="
		crossorigin=""/>

		<script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js"></script>

		<script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js"
		integrity="sha512-nMMmRyTVoLYqjP9hrbed9S+FzjZHW5gY1TWCHA5ckwXZBadntCNs8kEqAWdrb9O7rxbCaA4lKTIWjDXZxflOcA=="
		crossorigin=""></script>
</head>
<body>
<style type="text/css">
	.leaflet-popup-content-wrapper{

		min-width: 150%;
	}
.leaflet-popup-close-button{

	margin-left: 500%;
}

</style>
<?php
session_start();
require_once('connectMenu.php');
?>
	
            <!--Intro Section-->
            <section class="view intro-2 hm-gradient">
                <div class="full-bg-img test">
                    <div class="container">
                        <div class="row">
                        	<div class="col-md-4 offset-md-4 text-center mt-5">
                        	</div>
                        </div>
                        <div class="row">
                        	<div class="col-md-4 offset-md-4 text-center mt-5">
                        	</div>
                        </div>
                        <div class="row">
                        	<div class="col-md-12 test2 shadow-lg">
                        		
									<div id="mapid" ></div>
								
                        	</div>
                        </div>
                    </div>
                </div>
            </section>

			<!--Popup modal-->
			<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			  <div class="modal-dialog" role="document">
			    <div class="modal-content">
			      <div class="modal-header">
			        <h5 class="modal-title" id="exampleModalLabel">Identification</h5>
			        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			          <span aria-hidden="true">&times;</span>
			        </button>
			      </div>
			      <div class="modal-body">
			      	<form action="GestionConnexion.php" method="POST">
			  		<div class="form-group">
				        <label>Identifiant</label>
				        <input class="form-control" type="text" name="username"><br>
				    	</div>
			        <div class="form-group">
				        <label>Mot de passe</label>
				        <input class="form-control" type="password" name="password">
			      	</div>
			      <div class="modal-footer">
			      	<button type="submit" class="btn btn-primary" name="submitValidation">Se connecter</button>
			      	</form>
			        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
			      </div>
			    </div>
			  </div>
			</div>


	<script>
		//Instance de la map
		var mymap = L.map('mapid').setView([45, 12], 5);

		var datas = [
			id => feature.id,
			name => 'test',
			lat => 54.667,
			lon => 78.878
		];

		console.log(datas);


		L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
			attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
			maxZoom: 18,
			id: 'mapbox.streets',
			accessToken: 'pk.eyJ1IjoidGNvbXRlIiwiYSI6ImNqbTYwejkwdzAzc2QzcW54cDdkdGE1ZnYifQ.ckjNHA2niw5ZOpo8WkPRnw'
		}).addTo(mymap);

		// // load a tile layer
		// L.tileLayer('http://tiles.mapc.org/basemap/{z}/{x}/{y}.png',
		// {
		// 	attribution: 'Tiles by <a href="http://mapc.org">MAPC</a>, Data by <a href="http://mass.gov/mgis">MassGIS</a>',
		// 	maxZoom: 17,
		// 	minZoom: 9
		// }).addTo(mymap);


		var lgMarkers = new L.LayerGroup();

		//Marker sur la map + popup
		$.getJSON("map.geojson",function(data){
			L.geoJson(data,{
				pointToLayer: function(feature,latlng){
					var marker = L.marker(latlng);
					console.log(feature.id)
					marker.bindPopup("<div style='width: 150%;'><center><h1>Réservation </h1></center><hr><form action = '' method = 'post'><center>Hotel N° <strong><label>"+feature.id+"</label></strong></center><div class='row'><div class='col'><input type ='date' class='form-control' name='dateArrivee'></div><div class='col'><input type ='date' class='form-control' name='dateRentree' ></div></div></br><input type ='number' name='nbVoyageurs' class='form-control' placeholder='Nombre de personnes' min=1><br><center><button type = 'submit' class='btn btn-primary bnt-lg'> Réserver </button></center></form></div>");
					return marker;
				}
			}).addTo(lgMarkers);
		});


		lgMarkers.addTo(mymap);


		// function onStart() {
		// 	mymap.on('movestart', mymap.removeLayer(lgMarkers));
		// }
		// mymap.on('movestart', onStart());

		// function onScreen() {
		// 	mymap.on('moveend', lgMarkers.addTo(mymap));
		// 	return 0;
		// }
		// mymap.on('moveend', onScreen());

		mymap.on('movestart', (e) => mymap.removeLayer(lgMarkers));
		mymap.on('moveend', (e) => lgMarkers.addTo(mymap));
		



		// //Click on the map and get the Lat and Long
		// function onMapClick(e) {
		// 	alert("You clicked the map at " + e.latlng);
		// }

		// mymap.on('click', onMapClick);

		// var popup = L.popup();

		//Mini marker to tell where we are

		// function onMapClick(e) {
		// 	popup
		// 	.setLatLng(e.latlng)
		// 	.setContent("You clicked the map at " + e.latlng.toString())
		// 	.openOn(mymap);
		// }

		// mymap.on('click', onMapClick);


	</script>
</body>
</html>