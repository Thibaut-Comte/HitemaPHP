<?php


try{		$user="root";
			$pass="";	
			$base=new PDO('mysql:host=localhost;dbname=hitemaprojet', $user, $pass);
}
catch (PDOException $e) {
    print "Erreur !: " . $e->getMessage() . "<br/>";
    die();
}    

?>