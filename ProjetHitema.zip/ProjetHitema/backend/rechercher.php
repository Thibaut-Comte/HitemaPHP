<!DOCTYPE html>
<html>
<head>
	<title>Recherche</title>
	<script type="text/javascript" src="../javascript/AjaxMap.js"></script>
</head>
<body>

	<form action="#" method="post">
    	<input type="text" id="Ville" required>
    	<button type="submit" id="ValidationRequete">Rechercher</button>
	</form>
	<div id="demo"></div>
</body>

<script type="text/javascript"> GetNameMap(); </script>
</html>