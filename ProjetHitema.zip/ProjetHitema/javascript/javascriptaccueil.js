//popup
$('#myModal').on('shown.bs.modal', function () {
$('#myInput').trigger('focus')
})
// Animations init
new WOW().init();
