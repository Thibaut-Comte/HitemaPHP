function GetNameMap() {

var boutonRechercher=document.querySelector('#ValidationRequete'); // ton bouton ou tu veux executer ton ajax

boutonRechercher.addEventListener('click', function(e)
{

	e.preventDefault();
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("demo").innerHTML = this.responseText;  // Le retour affiche la page ou s'execute la requete, si etatRequete== 4 c'est bon ca a executé
    }
  };
  

  var VilleRecherche= encodeURIComponent(document.querySelector("#Ville").value);


    xhr.open("POST", "api.php", true);

	xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send("VilleRecherche=" + VilleRecherche);
});


}
