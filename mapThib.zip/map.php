
<!doctype html>
<html lang="fr">
<head>
	<meta charset="utf-8">
	<title>TestsMap</title>

	<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>

	<link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.4/dist/leaflet.css"
	integrity="sha512-puBpdR0798OZvTTbP4A8Ix/l+A4dHDD0DGqYW6RQ+9jxkRFclaxxQb/SJAWZfWAkuyeQUytO7+7N4QKrDh+drA=="
	crossorigin=""/>

	<script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js"></script>

	<script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js"
	integrity="sha512-nMMmRyTVoLYqjP9hrbed9S+FzjZHW5gY1TWCHA5ckwXZBadntCNs8kEqAWdrb9O7rxbCaA4lKTIWjDXZxflOcA=="
	crossorigin=""></script>

	<link rel="stylesheet" href="./css/map.css">

	<script src="script.js"></script>
</head>
<body>

	<div id="mapid"></div>
	<input type="hidden" name="id" value="">
	<input type="hidden" name="name" value="">

	<script>
		//Instance de la map
		var mymap = L.map('mapid').setView([42.355988, -71.157609], 13);

		var datas = [
			id => feature.id,
			name => 'test',
			lat => 54.667,
			lon => 78.878
		];

		console.log(datas);


		L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
			attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
			maxZoom: 18,
			id: 'mapbox.streets',
			accessToken: 'pk.eyJ1IjoidGNvbXRlIiwiYSI6ImNqbTYwejkwdzAzc2QzcW54cDdkdGE1ZnYifQ.ckjNHA2niw5ZOpo8WkPRnw'
		}).addTo(mymap);

		// // load a tile layer
		// L.tileLayer('http://tiles.mapc.org/basemap/{z}/{x}/{y}.png',
		// {
		// 	attribution: 'Tiles by <a href="http://mapc.org">MAPC</a>, Data by <a href="http://mass.gov/mgis">MassGIS</a>',
		// 	maxZoom: 17,
		// 	minZoom: 9
		// }).addTo(mymap);


		var lgMarkers = new L.LayerGroup();

		//Marker sur la map + popup
		$.getJSON("rodents.geojson",function(data){
			L.geoJson(data,{
				pointToLayer: function(feature,latlng){
					var marker = L.marker(latlng);
					marker.bindPopup("<form action = '' method = 'post'> <input type='hidden' name='datas' value='"+ feature +"'/> <input disabled='true' type='text' name = 'location' value = '"+feature.properties.Location+"'/>" + "<br/> <input disabled='true' type='text' name = 'openDT' value = '"+feature.properties.OPEN_DT+"'/>" + "<br><label>Dates d'aller et de retour de votre voyage</label><br><input type ='date' name='dateArrivee'><br><input type ='date' name='dateRentree' ><br><input type ='number' name='nbVoyageurs' placeholder='Nombre de personnes' min=1><br><button type = 'submit'> Réserver </button></form>");
					return marker;
				}
			}).addTo(lgMarkers);
		});


		lgMarkers.onAdd(mymap);


		// function onStart() {
		// 	mymap.on('movestart', mymap.removeLayer(lgMarkers));
		// }
		// mymap.on('movestart', onStart());

		// function onScreen() {
		// 	mymap.on('moveend', lgMarkers.addTo(mymap));
		// 	return 0;
		// }
		// mymap.on('moveend', onScreen());

		mymap.on('movestart', (e) => mymap.removeLayer(lgMarkers));
		mymap.on('moveend', (e) => lgMarkers.addTo(mymap));
		



		// //Click on the map and get the Lat and Long
		// function onMapClick(e) {
		// 	alert("You clicked the map at " + e.latlng);
		// }

		// mymap.on('click', onMapClick);

		// var popup = L.popup();

		//Mini marker to tell where we are

		// function onMapClick(e) {
		// 	popup
		// 	.setLatLng(e.latlng)
		// 	.setContent("You clicked the map at " + e.latlng.toString())
		// 	.openOn(mymap);
		// }

		// mymap.on('click', onMapClick);


	</script>
</body>
</html>